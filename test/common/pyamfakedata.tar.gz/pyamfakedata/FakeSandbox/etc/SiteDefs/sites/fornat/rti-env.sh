. ${YAM_ROOT}/etc/SiteDefs/sites/rti-env.sh

# add site specific customization and overrides below
# STETHOSCOPEHOME=${RTIHOME}/scope.5.0d
# RTILIBHOME=${RTIHOME}/rtilib.3.7l
# NDDSHOME=${RTIHOME}/ndds.1.11q
# CONTROLSHELLHOME=${RTIHOME}/cs.5.2b
# RTIMAKEHOME=${CONTROLSHELLHOME}/makehome
# MAKEHOME=${RTIMAKEHOME}
# MYMAKEHOME=${RTIMAKEHOME}
# PATH=${STETHOSCOPEHOME}/bin/${OS_ARCH}:${NDDSHOME}/bin/${OS_ARCH}:${PATH}
