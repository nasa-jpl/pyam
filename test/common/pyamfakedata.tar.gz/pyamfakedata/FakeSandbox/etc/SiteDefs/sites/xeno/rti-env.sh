. ${YAM_ROOT}/etc/SiteDefs/sites/rti-env.sh

# add site specific customization and overrides below
